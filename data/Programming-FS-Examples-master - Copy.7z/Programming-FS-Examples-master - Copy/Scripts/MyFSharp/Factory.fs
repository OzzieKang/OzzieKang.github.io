﻿module Alpha
/// Compute the greatest common divisor of
/// two numbers. 
module MathFunction=
    let rec GetGreatedCommonDivisor x y =
        if y = 0 then x
        else GetGreatedCommonDivisor y (x % y)

module ConversionUtils=
    let intToString (x: int) = x.ToString()
    module ConvertBase=
        let convertToHex x = sprintf "%x" x
        let convertToOct x = sprintf "%o" x

module DataTypes=
    type Point = Point of float * float * float


module Util=
    open System
    open System.IO
    module FolderUtil=
        let sizeOfFolder folder =
            let filesInFolder : string [] =
                Directory.GetFiles(folder,"*.*",SearchOption.AllDirectories)
            let fileInfos: FileInfo [] =
                Array.map (fun (file: string)-> new FileInfo(file)) filesInFolder
            let fileSizes: int64 [] =
                Array.map (fun (info: FileInfo) -> info.Length) fileInfos
            let totalSize = Array.sum fileSizes
            totalSize

        let uglySizeOfFolder folder=
            Array.sum
                (Array.map
                    (fun (info: FileInfo) -> info.Length)
                    (Array.map
                        (fun (file: string)-> new FileInfo(file))
                        (Directory.GetFiles(folder,"*.*",SearchOption.AllDirectories))))

        let sizeOfFolderPiped folder= 
            let getFiles path=
                Directory.GetFiles(path,"*.*",SearchOption.AllDirectories)
            let totalSize=
                folder
                |> getFiles
                |> Array.map (fun file -> new FileInfo(file))
                |> Array.map (fun info -> info.Length)
                |> Array.sum
            totalSize

        let sizeOfFolderComposed (*No Parameters!*)=
            let getFiles folder = Directory.GetFiles(folder,"*.*",SearchOption.AllDirectories)
            getFiles
            >> Array.map (fun file -> new FileInfo (file))
            >> Array.map (fun info -> info.Length)
            >> Array.sum
