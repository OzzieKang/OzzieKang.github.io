﻿namespace PlayingCards

type Suit=
    | Spade
    | Club
    | Diamond
    | Heart

type PlayingCard = 
    | Ace of Suit
    | King of Suit
    | Queen of Suit
    | Jack of Suit
    | ValueCard of int * Suit

type PokerPlayer = {Name: string; Money : int; Position : int}


