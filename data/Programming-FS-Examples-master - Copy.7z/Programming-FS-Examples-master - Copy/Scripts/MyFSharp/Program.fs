﻿namespace Program
// Learn more about F# at http://fsharp.net
// See the 'F# Tutorial' project for more help.

module MyFSharp =
    let numbers = [1 .. 10]
    let square x = x * x
    let squaredNumbers = List.map square numbers
    printfn "SquaredNumbers = %A" squaredNumbers
    open System
    
    let x=Alpha.MathFunction.GetGreatedCommonDivisor 20 6
    printfn "GreatedCommonDivisor is %A" x

    let f x = x ** 2.0 + x
    let g x = x + 1.0
    
    let imperativeSum numbers=
        let mutable total = 0
        for i in numbers do
            let x = square i
            total <- total + x
        total
    
    let functionalSum numbers=
        numbers
        |> Seq.map square
        |> Seq.sum

        
    let z = imperativeSum [1 .. 10]
    printfn "SquaredNumbers = %A" z

    //lambda expression
    let lambda = (fun x -> x + 3) 5
    printfn "lambda = %A" lambda

    let lambdaList= List.map (fun i -> -i) [1 .. 10]
    printfn "lambdaList = %A" lambdaList

    //Append text to a file
    open System.IO

    let appendFile (fileName: string) (text : string) =
        use file = new StreamWriter (fileName,true)
        file.WriteLine(text)
        file.Close()
    
    let appendLogFile = appendFile @"C:\Temp\log.txt"
    appendFile @"C:\Temp\log.txt" "Hello"
    appendLogFile "world"

    //List.iter (fun i -> printfn "%d" i) [1..5]
    List.iter (printfn "%d") [6..10]


    //Example 3-3. Functions returning functions
    let generatePowerOfFunc baseValue =
        (fun exponent -> baseValue ** exponent)

    let powerOfTwo = generatePowerOfFunc 2.0
    let powerOfThree = generatePowerOfFunc 3.0
    powerOfTwo 3.0
    powerOfThree 2.0

    // Define a recursive function
    let rec factorial x=
        if x <=1 then
            1
        else
            x * factorial (x-1)
    
    factorial 5

    // Functional for loop
    let rec forLoop body times=
        if times<=0 then
            ()
        else
            body()
            forLoop body (times - 1)

    // Functional while loop
    let rec whileLoop predicate body =
        if predicate() then
            body()
            whileLoop predicate body
        else
            ()
    
    forLoop (fun () -> printfn "Looping...") 3

//    whileLoop (fun () -> DateTime.Now.DayOfWeek <> DayOfWeek.Sunday) (fun () -> printfn "I wish it were the weekend...")
    
    // Mutually recursive functions using "rec" and "and".
    let rec isOdd x =
        if x = 0 then false
        elif x =1 then true
        else isEven(x-1)
    and isEven x =
        if x = 0 then true
        elif x = 1 then false
        else isOdd(x-1)
    
    isOdd 314
    isEven 314

    let CheckODD x=
        (x%2=0 || x=0)

    CheckODD 314

    //Factorial
    let rec (!) x =
        if x<=1 then 1
        else x * !(x-1)
    
    !5

    open System.Text.RegularExpressions

    let (===) str (regex:string) = 
        Regex.Match(str,regex).Success

    "The Quick brown fox"  === "The (.*) fox"

    List.fold (-) 10 [3;3;3]

    List.fold (+) 0 [1..10]

    List.fold (*) 1 [1..10]

    let sizeOfFolder = Alpha.Util.FolderUtil.sizeOfFolder @"C:\Temp"

    printfn "sizeOfFolder %A" sizeOfFolder

    let (|>) x f = f x

    [1 .. 3] |> List.iter(printfn "%d")
    
    let sizeOfFolderPip = Alpha.Util.FolderUtil.sizeOfFolderPiped @"C:\Temp"

    printfn "sizeOfFolderPip %A" sizeOfFolderPip

    ["Pipe"; "Forward"] |> List.iter (fun s -> printfn "s has length %d" s.Length)

    let sizeOfFolderComposed = Alpha.Util.FolderUtil.sizeOfFolderComposed @"C:\Temp"

    printfn "sizeOfFolderPip %A" sizeOfFolderComposed

    printfn "(press any key to continue)"
    Console.ReadKey(true) |> ignore