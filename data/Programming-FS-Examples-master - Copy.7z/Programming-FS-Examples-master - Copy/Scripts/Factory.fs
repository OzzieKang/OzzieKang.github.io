﻿module Alpha
/// Compute the greatest common divisor of
/// two numbers. 
module MathFunction=
    let rec GetGreatedCommonDivisor x y =
        if y = 0 then x
        else GetGreatedCommonDivisor y (x % y)

module ConversionUtils=
    let intToString (x: int) = x.ToString()
    module ConvertBase=
        let convertToHex x = sprintf "%x" x
        let convertToOct x = sprintf "%o" x

module DataTypes=
    type Point = Point of float * float * float


