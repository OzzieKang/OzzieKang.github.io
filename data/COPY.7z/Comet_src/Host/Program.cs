﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using RestService;

namespace Host
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                WebServiceHost hostForm = new WebServiceHost(typeof(FormSvc));
                hostForm.Open();

                ReadKeyToQuit("FormSvc started.\nTo quit press any key... ");

                FormSvc.StopAll();
                hostForm.Close();
            }
            catch (Exception e)
            {
                ReadKeyToQuit("Exception:\n" + e.ToString());
            }
        }

        static void ReadKeyToQuit(string msg)
        {
            Console.WriteLine(msg);
            Console.ReadKey();
        }
    }
}
