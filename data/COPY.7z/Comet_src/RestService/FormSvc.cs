﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.IO;
using System.Xml;
using System.Net;
using System.Threading;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using CometSvcLib;

namespace RestService
{
    [ServiceContract]
    interface IFormSvc
    {
        [OperationContract]
        [WebGet(UriTemplate = "", BodyStyle = WebMessageBodyStyle.Bare)]
        Message Init();
    }

    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    public class FormSvc : IFormSvc
    {
        private static Comet comet;

        private static List<FormSvc> lstForm = new List<FormSvc>();

        private AutoResetEvent ev = null;
        private Thread thread = null;
        private string clientId;
        private static readonly string formTemplate;
        private static int clientCount = 0;

        static FormSvc()
        {
            try
            {
                comet = new Comet();
            }
            catch (Exception e)
            {
                Console.WriteLine("\nError: Notification service can not be created.\n{0}\n", e);
            }

            formTemplate = File.ReadAllText("FormTemplate.html");
           
            Comet.timeout = new TimeSpan(0, 0, 30);
            Comet.dlgtGetResponseString = (clientId => 
                {
                    return "TIME: " + DateTime.Now.ToString(); 
                });
        }

        public FormSvc()
        {
            clientId = Interlocked.Increment(ref clientCount).ToString();

            lock (typeof(FormSvc))
            {
                lstForm.Add(this);
            }
        }

        public Message Init()
        {
            if (thread == null)
            {
                thread = new Thread(param => 
                        {
                            // "Useful processing"
                            Random x = new Random();
                            ev = new AutoResetEvent(false);
                            while (!ev.WaitOne(new TimeSpan(0, 0, x.Next(0, 60))))
                            {
                                Comet.SetEvent(clientId);
                            }
                        });
                thread.Start(null);
            }

            return Comet.GenerateResponseMessage(formTemplate.Replace("{URI}", comet.CometSvcAddress).Replace("{ID}", clientId), 
                                                 HttpStatusCode.OK);
        }

        public static void StopAll()
        {
            lock (typeof(FormSvc))
            {
                foreach (FormSvc form in lstForm)
                    form.Stop();
            }
        }

        private void Stop()
        {
            if (ev != null)
                ev.Set();
            if (thread != null)
                thread.Join();
        }
    }
}
