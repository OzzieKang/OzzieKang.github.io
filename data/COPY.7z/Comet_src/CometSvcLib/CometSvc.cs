﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Xml;
using System.Net;
using System.Runtime.Serialization;
using System.Threading;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;

namespace CometSvcLib
{
    [ServiceContract(SessionMode = SessionMode.NotAllowed)]
    public interface ICometSvc
    {
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = CometSvc.NOTIFICATION + "/{clientId}/{dummy}", BodyStyle = WebMessageBodyStyle.Bare)]
        Message Notification(string clientId, string dummy);
    }

    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall)]
    public class CometSvc : ICometSvc
    {
        public const string NOTIFICATION = "/Notification";
        private AutoResetEvent ev = new AutoResetEvent(false);

        public Message Notification(string clientId, string dummy)
        {
            Console.WriteLine("ClientId = {0}, dummy = {1}", clientId, dummy);

            string arg;
            HttpStatusCode statusCode = HttpStatusCode.OK;

            if (Comet.dlgtGetResponseString != null)
            {
                Comet.RegisterCometInstance(clientId, this);

                if (ev.WaitOne(Comet.timeout))
                {
                    lock (typeof(Comet))
                    {
                        arg = Comet.dlgtGetResponseString(clientId);
                    }
                }
                else
                    arg = string.Format("Timeout Elapsed {0}", clientId);

                Comet.UnregisterCometInstance(clientId);
            }
            else
            {
                arg = "Error: Response generation is not implemented";
                Console.WriteLine(arg);

                statusCode = HttpStatusCode.InternalServerError;
            }

            return Comet.GenerateResponseMessage(arg, statusCode);
        }

        internal void SetEvent()
        {
            ev.Set();
        }
    }  
}
