﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;

namespace CometSvcLib
{
    public class Comet : IDisposable
    {
        private WebServiceHost hostComet = null;
        private static Dictionary<string, CometSvc> dctSvc = new Dictionary<string, CometSvc>();

        public delegate string GetResponseStringDelegate(string clientId);
        public static GetResponseStringDelegate dlgtGetResponseString = null;

        public static TimeSpan timeout = new TimeSpan(0, 0, 55);

        public Comet()
        {
            hostComet = new WebServiceHost(typeof(CometSvc));
            hostComet.Open();
        }

        public string CometSvcAddress
        {
            get
            {
                return string.Format("{0}{1}", hostComet.BaseAddresses[0], CometSvc.NOTIFICATION);
            }
        }

        public void Close()
        {
            Dispose();
        }

        public void Dispose()
        {
            if (hostComet != null && hostComet.State == CommunicationState.Opened)
                hostComet.Close();
        }

        internal static void RegisterCometInstance(string clientId, CometSvc cometSvc)
        {
            lock (typeof(Comet))
            {
                Comet.dctSvc[clientId] = cometSvc;
            }
        }

        internal static void UnregisterCometInstance(string clientId)
        {
            lock (typeof(Comet))
            {
                if (dctSvc.ContainsKey(clientId))
                    Comet.dctSvc.Remove(clientId);
            }
        }

        public static void SetEvent(string clientId)
        {
            CometSvc cometSvc;

            lock (typeof(Comet))
            {
                dctSvc.TryGetValue(clientId, out cometSvc);
            }

            if (cometSvc != null)
                cometSvc.SetEvent();
        }

        public static Message GenerateResponseMessage(string strResponse, HttpStatusCode statusCode)
        {
            XmlReader xr;
            try
            {
                xr = XmlReader.Create(new StringReader("<i>" + strResponse + "</i>"));
            }
            catch
            {
                xr = XmlReader.Create(new StringReader("<i>Wrong Response.</i>"));
            }

            Message response = Message.CreateMessage(MessageVersion.None, string.Empty, xr);
            HttpResponseMessageProperty responseProperty = new HttpResponseMessageProperty();
            responseProperty.Headers.Add("Content-Type", "text/html");
            response.Properties.Add(HttpResponseMessageProperty.Name, responseProperty);
            (response.Properties.Values.ElementAt(0) as HttpResponseMessageProperty).StatusCode = statusCode;
            
            return response;
        }
    }
}
