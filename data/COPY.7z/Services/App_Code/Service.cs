﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using Toolkit;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single, IncludeExceptionDetailInFaults = true)]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class Service : System.Web.Services.WebService
{
    private string RequestType = "";
    private string CurrentUser = "";

    private string connstr = System.Configuration.ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;

    private string SQL_BLOG_LIST = "select id, introText, blogText, postDate, who from blog_Content";

    private string SQL_BLOG_LIST_ITEM = "select id, introText, blogText, postDate, who from blog_Content WHERE id={0}";

    private string SQL_BLOG_NEW = "insert into blog_Content (introText,blogText,who) values ('{0}','{1}','{2}')";

    private string SQL_BLOG_COMMENT = "select commentText from blog_Comment WHERE blogId={0}";

    private string SQL_BLOG_COMMENT_NEW = "insert into blog_Comment (blogId,commentText,who) values ('{0}','{1}','{2}')";

    private string SQL_BLOG_USER = "SELECT COUNT(id) from blog_User where username='{0}' and password='{1}'";

    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
        //获取Request Type
        RequestType = HttpContext.Current.Request.HttpMethod;
        CurrentUser = HttpContext.Current.Request.Params["LOGON_USER"];
    }

    [WebMethod]
    [ScriptMethod(UseHttpGet = true, ResponseFormat = ResponseFormat.Json)]
    public void BlogList()
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();

        List<blog> blogs = server.Select_List<blog>(SQL_BLOG_LIST, connstr);

        //foreach (blog b in blogs)
        //{
        //    b.introText = string.Join(" ",b.blogText.Split(new[]{' '}).Take(15))+"......";
        //}

        Context.Response.Clear();
        //Context.Response.ContentType = "application/json";
        Context.Response.Write(Tookit.SerializeToJson(blogs));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void GetBlog(string id)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();
        string blog = string.Format(SQL_BLOG_LIST_ITEM, id);
        string commen = string.Format(SQL_BLOG_COMMENT, id);
        blog blo = server.Select_T<blog>(blog, connstr);
        List<comment> comments = server.Select_List<comment>(commen, connstr);

        blo.comments = comments;

        Context.Response.Clear();
        //Context.Response.ContentType = "application/json";
        Context.Response.Write(Tookit.SerializeToJson(blo));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public bool login(string username, string password)
    {
        return ValidateUser(new who { username = username, password = password });
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public bool logMeIn(who user)
    {
        return ValidateUser(user);
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public bool commentOperation(comment newcomment)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();
        string newcomments = string.Format(SQL_BLOG_COMMENT_NEW, newcomment.blogId, newcomment.commentText, newcomment.who);
        server.Update_Query(newcomments, connstr);
        return true;
    }


    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void EasyBlog(blog myblog)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();

        if (RequestType == "GET")
        {
            string blog = string.Format(SQL_BLOG_LIST_ITEM, myblog._id);
            string commen = string.Format(SQL_BLOG_COMMENT, myblog._id);
            blog blo = server.Select_T<blog>(blog, connstr);
            List<comment> comments = server.Select_List<comment>(commen, connstr);

            blo.comments = comments;

            Context.Response.Clear();
            //Context.Response.ContentType = "application/json";
            Context.Response.Write(Tookit.SerializeToJson(blo));
        }
        else if (RequestType == "POST")
        {
            string intro = myblog.introText.Replace("'", "''");
            string blogText = myblog.blogText.Replace("'", "''");
            string user = myblog.who.Replace("'", "''");

            string sql = string.Format(SQL_BLOG_NEW, intro, blogText, user);
            server.Update_Query(sql, connstr);
            //Context.Response.Clear();
            //Context.Response.Write("{updated: true}");
            //Context.Response.Flush();
            //Context.Response.End();
        }

    }

    private List<RequestParam> GetAllRequestParameters()
    {
        List<RequestParam> parameters = new List<RequestParam>();
        RequestParam para;
        foreach (string s in HttpContext.Current.Request.Params.Keys)
        {

            para = new RequestParam() { key = s.ToString(), value = HttpContext.Current.Request.Params[s] };
            parameters.Add(para);
            //Response.Write(s.ToString() + ":" + Request.Params[s] + "<br>");
        }

        return parameters;
    }

    private bool ValidateUser(who user)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();
        int count = (int)server.Select_SingleData(string.Format(SQL_BLOG_USER, user.username, user.password), connstr);
        return count > 0;
    }

    [Serializable]
    public class blog
    {
        public int _id { set; get; }
        public string introText { set; get; }
        public string blogText { set; get; }
        public DateTime date { set; get; }
        public string who { set; get; }
        public List<comment> comments { set; get; }
    }

    [Serializable]
    public class comment
    {
        public string commentText { set; get; }
        public int blogId { set; get; }
        public string who { set; get; }
    }

    [Serializable]
    public class who
    {
        public string username { set; get; }
        public string password { set; get; }
    }

    [Serializable]
    private class RequestParam
    {
        public object key { set; get; }
        public object value { set; get; }
    }
}