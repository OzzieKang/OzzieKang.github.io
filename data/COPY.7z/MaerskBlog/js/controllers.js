﻿'use strict'
/* Controller*/

var blogControllers = angular.module('blogControllers', []);

blogControllers.controller('BlogCtrl', ['$scope', 'BlogList','$location','checkCreds',
function BlogCtrl($scope, BlogList,$location,checkCreds) {
    if (!checkCreds()) {
        $location.path('/login');
        return;
    }
    $scope.brandColor = "color:white;";
    $scope.blogList = [];
    BlogList.get({},
        function success(response) {
            LogCat("Success", response);
            $scope.blogList = response;
        },
        function error(errorResponse) {
            LogCat("Error", errorResponse);
        });

    $scope.formatDate = function (date) {
       return GetMSSQLJsonDate(date);
    };
}]);


blogControllers.controller('BlogViewCtrl',
['$scope', '$routeParams', 'BlogDetail', 'BlogPostComments', '$location', 'checkCreds', '$http', 'getToken', '$route', 'getUsername',
function BlogViewCtrl($scope, $routeParams, BlogDetail, BlogPostComments, $location, checkCreds, $http, getToken, $route, getUsername) {
    if (!checkCreds()) {
        $location.path('/login');
        return;
    }

    var blogId = $routeParams.id;
    $scope.blg = 1;

    BlogDetail.get({ id: blogId },
        function success(response) {
            LogCat("Success", response);
            $scope.blogEntry = response;
            $scope.blogId = response._id;
        },
        function error(errorResponse) {
            LogCat("Error", errorResponse);
        }
    );

    $scope.formatDate = function (date) {
        return GetMSSQLJsonDate(date);
    };

    $scope.submit = function () {
        $scope.sub = true;
        $http.defaults.headers.common['Authorization'] = 'Basic ' + getToken();
        var newcomment = {
            "commentText": $scope.commentText,
            "blogId": $scope.blogId,
            "who": getUsername()
        };

        var postData = "{newcomment:" + JSON.stringify(newcomment) + "}";

        BlogPostComments.save({}, postData,
            function success(response) {
                LogCat("Success", response);
                $location.path('/blogPost/' + $scope.blogId);
                $route.reload();
            },
            function error(errorResponse) {
                LogCat("Error", errorResponse);
            }
        );
    };
}]);


blogControllers.controller('LoginCtrl', ['$scope', '$location', 'Login', 'setCreds',  function LoginCtrl($scope, $location, Login, setCreds) {
    $scope.error = "";
    $scope.submit = function () {
        $scope.sub = true;

        var user = {
            "username":$scope.username,
            "password":$scope.password
        }

        var postData = "{user:" + JSON.stringify(user) + "}";

        Login.login({},postData,
            function success(response) {
                LogCat("Success", response);
                var authenticated = response.d;
                if (authenticated) {
                    setCreds($scope.username, $scope.password);
                    $location.path('/');
                } else {
                    $scope.error = "Login Failed";
                }
            },
            function error(errorResponse) {
                LogCat("Error", errorResponse);
            }
        );
    };
}]);


blogControllers.controller('LogoutCtrl', [ '$location', 'deleteCreds', function LogoutCtrl($location, deleteCreds) {
    deleteCreds();
    $location.path('/login');
}]);


blogControllers.controller('NewBlogPostCtrl',
['$scope', 'BlogPost', '$location', 'checkCreds', '$http', 'getToken','getUsername',
function NewBlogPostCtrl($scope, BlogPost, $location, checkCreds, $http, getToken, getUsername) {
    if (!checkCreds()) {
        $location.path('/login');
        return;
    }

    $scope.languageList = [
        {
            "id": 1,
            "name": "English"
        },
        {
            "id": 2,
            "name": "Spanish"
        },
        {
            "id": 3,
            "name": "中文"
        }
    ];

    $scope.languageId = 1;
    $scope.newActiveClass = "active";
    $scope.submit = function () {
        $scope.sub = true;
        $http.defaults.headers.common['Authorization'] = 'Basic ' + getToken();
        var myblog = {
            "introText": $scope.introText,
            "blogText": $scope.blogText,
            "who": getUsername()
            //"languageId": $scope.languageId
        };

        var postData = "{myblog:" + JSON.stringify(myblog) + "}";

        BlogPost.save({}, postData,
            function success(response) {
                console.log("Success:" + JSON.stringify(response));
                $location.path('/');
            },
            function error(errorResponse) {
                console.log("Error:" + JSON.stringify(errorResponse));
        });
    };
}]);


blogControllers.controller('AboutBlogCtrl', ['$scope','$location', 'checkCreds',
function AboutBlogCtrl($scope, $location, checkCreds) {
    if (!checkCreds()) {
        $location.path('/login');
    }
    $scope.aboutActiveClass = "active";
}]);


/*Start: Public Methods*/

//Log the message
function LogCat(logString,message) {
    console.log(logString + ":" + JSON.stringify(message));
}

//Formate the date data of MS SQL Server
function GetMSSQLJsonDate(input) {
    var dateOut = Number((input + "").replace(/\/Date\((\d+)\)\//gi, "$1"));
    var newdate = new Date(dateOut);
    return dateOut;
}
/*End: Public Methods*/