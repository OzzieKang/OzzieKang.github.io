﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using Toolkit;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single, IncludeExceptionDetailInFaults = true)]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class Service : System.Web.Services.WebService
{
    private string RequestType = "";

    private string connstr = "Data Source=SAPMSQLCNCGD001;Initial Catalog=NGA;User Id=cgdgscdoc;Password=cgdgscdoc;";

    private string SQL_BLOG_LIST = "select id ,blogText, postDate from blog_Content";
    private string SQL_BLOG_LIST_ITEM = "select id ,blogText, postDate from blog_Content WHERE id={0}";
    private string SQL_BLOG_COMMENT = "select commentText from blog_Comment WHERE blogId={0}";
    private string SQL_BLOG_COMMENT_NEW = "insert into blog_Comment (blogId,commentText,who) values ({0},'{1}','{2}')";
    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
        //获取Request Type
        RequestType = HttpContext.Current.Request.HttpMethod;
    }

    [WebMethod]
    [ScriptMethod(UseHttpGet = true, ResponseFormat = ResponseFormat.Json)]
    public void BlogList()
    {
        SQLServerHelper.SQLSever server=new SQLServerHelper.SQLSever();

        List<blog> blogs = server.Select_List<blog>(SQL_BLOG_LIST, connstr);
        foreach (blog b in blogs)
        {
            b.introText = string.Join(" ",b.blogText.Split(new[]{' '}).Take(15))+"......";
        }

        Context.Response.Clear();
        //Context.Response.ContentType = "application/json";
        Context.Response.Write(Tookit.SerializeToJson(blogs));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void GetBlog(int id)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();
        string blog = string.Format(SQL_BLOG_LIST_ITEM, id);
        string commen=string.Format(SQL_BLOG_COMMENT, id);
        //List<blog> blogs = server.Select_List<blog>(blog, connstr);
        blog blo = server.Select_T<blog>(blog, connstr);
        List<comment> comments = server.Select_List<comment>(commen, connstr);

        blo.comments = comments;

        Context.Response.Clear();
        //Context.Response.ContentType = "application/json";
        Context.Response.Write(Tookit.SerializeToJson(blo));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat=ResponseFormat.Json)]
    public bool login(user bloguser)
    {
        if (bloguser.username == "oks006" && bloguser.password == "123456")
            return true;
        else
            return false;
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public bool commentOperation(comment newcomment)
    {
        SQLServerHelper.SQLSever server = new SQLServerHelper.SQLSever();
        string newcomments = string.Format(SQL_BLOG_COMMENT_NEW, newcomment.blogId, newcomment.commentText, newcomment.who);
        server.Update_Query(newcomments, connstr);
        return true;
    }

    public class blog
    {
        public int _id { set; get; }
        public string blogText { set; get; }
        public DateTime date { set; get; }
        public string introText { set; get; }
        public List<comment> comments { set; get; }
    }

    public class comment
    {
        public string commentText { set; get; }
        public int blogId { set; get; }
        public string who { set; get; }
    }

    public class user
    {
        public string username { set; get; }
        public string password { set; get; }
    }
}