﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
namespace Toolkit
{
    /// <summary>
    /// Summary description for Tookit
    /// </summary>
    public class Tookit
    {
        public Tookit()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public static object SerializeDataTable(DataTable dt)
        {
            return SerializeToJson(dt);
        }

        public static string SerializeToJson(object list)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(list);
        }

        private static string SerializeToJson(DataTable table)
        {
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            int i = 0;
            Dictionary<string, object> row;
            foreach (DataRow x in table.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    row.Add(col.ColumnName, x[col]);
                }
                row.Add("index", i);
                rows.Add(row);
                i++;
            }
            return SerializeToJson(rows);
        }
    }
}
