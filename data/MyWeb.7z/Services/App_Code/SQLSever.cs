﻿//Purpose to facilitate the SQL Database operation
//Author: Ozzie
//2016-08-20

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace SQLServerHelper
{
    public class SQLSever
    {
        private SqlConnection connection;
        private SqlCommand cmd;
        private SqlDataAdapter adapter;
        private SqlDataReader reader;
        private SqlTransaction transaction;

        /// <summary>
        /// Open Sql connection
        /// </summary>
        /// <param name="connstr">Conneciton String</param>
        /// <returns>SqlConnection</returns>
        public SqlConnection GetConnection(string connstr)
        {
            try
            {
                connection = new SqlConnection(connstr);
                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }
                return connection;            
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Close Sql server connection
        /// </summary>
        public void CloseConnection()
        {
            try
            {
                if (connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        /// <summary>
        /// Execute the Normal SQL Queries
        /// </summary>
        /// <param name="QueryString"></param>
        /// <param name="ConnectionString"></param>
        /// <returns>DataSet</returns>
        public DataTable Select_DataTable(string QueryString, string ConnectionString)
        {
            DataTable datatable = new DataTable();

            try
            {
                using (cmd = new SqlCommand(QueryString, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.Text;
                    using (adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(datatable);
                        return datatable;
                    }
                }
            }
            catch (Exception e)
            {
                //RecordError(ConnectionString, QueryString, e.ToString());
                throw e;
            }
            finally
            {
                
                CloseConnection();
            }
        }

        public List<T> Select_List<T>(string QueryString, string ConnectionString) where T : new()
        {
            List<T> list = new List<T>();

            try
            {
                using (cmd = new SqlCommand(QueryString, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.Text;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(ReaderStreamToClass<T>(reader));
                        }
                    }
                }
                return list;
            }
            catch (Exception e)
            {
                //RecordError(ConnectionString, QueryString, e.ToString());
                throw e;
            }
            finally
            {
                CloseConnection();
            }

        }

        public object Select_SingleData(string QueryString, string ConnectionString)
        {
            try
            {
                using (cmd = new SqlCommand(QueryString, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.Text;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            return reader.GetValue(0);
                        }
                    }
                }
                return null;
            }
            catch (Exception e)
            {
                //RecordError(ConnectionString, QueryString, e.ToString());
                throw e;
            }
            finally
            {
                CloseConnection();
            } 
        }

        public T Select_T<T>(string QueryString, string ConnectionString) where T : new()
        {
            T t = new T();

            try
            {
                using (cmd = new SqlCommand(QueryString, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.Text;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                           return ReaderStreamToClass<T>(reader);
                        }
                    }
                }
                return t;
            }
            catch (Exception e)
            {
                //RecordError(ConnectionString, QueryString, e.ToString());
                throw e;
            }
            finally
            {
                CloseConnection();
            }
        }

        private T ReaderStreamToClass<T>(SqlDataReader reader) where T : new()
        {
            T t = new T();
            var type = t.GetType();
            var properties = type.GetProperties();
            int j = 0;
            foreach (var property in properties)
            {
                if (j > reader.FieldCount - 1) { break; }
                var value = reader.GetValue(j);
                if (value == DBNull.Value)
                {
                    property.SetValue(t, null, null);
                }
                else
                {
                    property.SetValue(t, value, null);
                }
                j++;
            }
            return t;
        }

        public DataSet Select_DataSet(List<QueryInfo> Queryinformations, string ConnectionString)
        {
            DataSet dataset = new DataSet();
            try
            {
                GetConnection(ConnectionString);

                using (cmd = new SqlCommand())
                {
                    foreach (QueryInfo querinfo in Queryinformations)
                    {
                        cmd.CommandText = querinfo.Query;
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        using (adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dataset, querinfo.QueryName);
                        }
                    }
                }
                return dataset;
            }
            catch (Exception e)
            {
                //foreach (QueryInfo q in Queryinformations)
                //{
                //    RecordError(ConnectionString, q.Query, e.ToString());
                //}
                throw e;
            }
            finally
            {
                CloseConnection();
            }
        }

        public DataTable Select_DataTable(string ProcedureName, SqlParameter[] parametes,string ConnectionString)
        {
            DataTable datatable = new DataTable();

            try
            {
                using (cmd = new SqlCommand(ProcedureName, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parametes != null)
                    {
                        cmd.Parameters.AddRange(parametes);
                    }
                    using (adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(datatable);
                        return datatable;
                    }
                }
            }
            catch (Exception e)
            {
                //RecordError(ConnectionString, ProcedureName, e.ToString());
                throw e;
            }finally
            {
                CloseConnection();
            }
        }

        private DataTable Execute_ProcQuery(string procQuery, string ConnectinString)
        {
            DataTable datatable = new DataTable();
            try
            {
                SqlParameter[] sp = new SqlParameter[] {
                    new SqlParameter { ParameterName="@query", SqlDbType=SqlDbType.VarChar,Value=procQuery }
                };
                return Select_DataTable("Qry_Execute",sp,ConnectinString);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public int Update_Query(string QueryString, string ConnectionString)
        {
            try
            {
                using (cmd = new SqlCommand(QueryString, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.Text;
                    return cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                if (e.Message.ToString().Contains("deadlock"))
                {
                    System.Threading.Thread.Sleep(1000);
                    return Update_Query(QueryString, ConnectionString);
                }
                else
                {
                    //RecordError(ConnectionString, QueryString, e.ToString());
                    throw e;
                }
            }
            finally
            {
                CloseConnection();
            }
        }

        public int Update_Query(string[] QueryStrings, string ConnectionString)
        {
            int j = 0;
            try
            {
                GetConnection(ConnectionString);
                using (transaction = connection.BeginTransaction())
                {
                    using (cmd = new SqlCommand())
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Connection = connection;
                        cmd.Transaction = transaction;
                        for (int i = 0; i < QueryStrings.Length; i++)
                        {
                            cmd.CommandText = QueryStrings[i];
                            j = cmd.ExecuteNonQuery();
                            j++;
                        }
                    }
                    transaction.Commit();
                }
                return j;
            }
            catch (Exception e)
            {
                transaction.Rollback();
                if (e.Message.ToString().Contains("deadlock"))
                {
                    System.Threading.Thread.Sleep(1000);
                    return Update_Query(QueryStrings, ConnectionString);
                }
                else
                {
                    //RecordError(ConnectionString, QueryStrings[j], e.ToString());
                    throw e;
                }
            }
            finally
            {
                CloseConnection();
            }
        }

        public int Update_Query(string ProcedureName, SqlParameter[] parametes, string ConnectionString)
        {
            try
            {
                using (cmd = new SqlCommand(ProcedureName, GetConnection(ConnectionString)))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parametes != null)
                    {
                        cmd.Parameters.AddRange(parametes);
                    }

                    return cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                if (e.Message.ToString().Contains("deadlock"))
                {
                    System.Threading.Thread.Sleep(1000);
                    return Update_Query(ProcedureName, parametes, ConnectionString);
                }
                else
                {
                    //RecordError(ConnectionString, ProcedureName, e.ToString());
                    throw e;
                }
                
            }
            finally
            {
                CloseConnection();
            }
        }


        public bool BulkCopy(DataTable table, string tableName, string ConnectionString,List<ColMap> columMapping)
        {
            using (SqlConnection destinationConnection = GetConnection(ConnectionString))
            {
                using (SqlTransaction transaction = destinationConnection.BeginTransaction())
                { 
                    using(SqlBulkCopy bulkcopy=new SqlBulkCopy(destinationConnection,SqlBulkCopyOptions.CheckConstraints,transaction))
                    {
                        bulkcopy.BatchSize = 5000;
                        bulkcopy.DestinationTableName = tableName;
                        bulkcopy.BulkCopyTimeout = 50000000;
                        if(columMapping!=null)
                        {
                            foreach (ColMap map in columMapping)
                            {
                                bulkcopy.ColumnMappings.Add(map.source,map.destination);
                            }
                        }

                        try
                        {
                            bulkcopy.WriteToServer(table);
                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            transaction.Rollback();
                            throw ex;
                        }
                        finally
                        {
                            destinationConnection.Close();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Record the Errors in the Database
        /// </summary>
        /// <param name="ConnectionString"></param>
        /// <param name="query"></param>
        /// <param name="errormessage"></param>
        private void RecordError(string ConnectionString, string query, string errormessage)
        {
            string sql = "INSERT INTO tblmdwsQryexcep(uname,exception,query,datetime) VALUES('" + Environment.UserName.ToUpper().ToString() + "','" + errormessage.Trim().ToString().Replace("'", "") + "','" + query.Trim().ToString().Replace("'", "") + "',GETDATE()) ";
            try
            {
                Execute_ProcQuery(sql, ConnectionString);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public bool IsExist(string QueryString, string ConnectionString)
        {
            try
            {
                DataTable data = Select_DataTable(QueryString, ConnectionString);
                if (data.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }

    public class QueryInfo
    {
        public string Query { set; get; }
        public string QueryName { set; get; }
    }

    public class ColMap
    {
        public string source{set;get;}
        public string destination{set;get;}
    }
}
