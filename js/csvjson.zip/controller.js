﻿
//var NGAList = angular.module("NGAList", ['ngTable']);

NGAApp.factory('NGAToolsData', function () {

    var data = {};

    return {
        getData: function () {
            return data;
        },
        setData: function (responsedata) {
            data = responsedata;
        }
    };
});

NGAApp.factory('listID', function () {

    var data = {};

    return {
        getData: function () {
            return data;
        },
        setData: function (responsedata) {
            data = responsedata;
        }
    };
});

//NGAApp.factory('userid', ['$scope','$http', function ($scope,$http) {
//    var data = {};

//    return {
//        getData: function () {
//            if (isEmpty(data)) {
//                $scope.loadingIsDone = false;
//                var link = "../AI/data/UserControl.aspx";
//                $http.get(link).then(function (response) {
//                    data = response.data.records;
//                    $scope.loadingIsDone = true;
//                });
//            }
//            return data;
//        },
//        setData: function (responsedata) {
//            data = responsedata;
//        }
//    };
//}]);

NGAApp.controller("dashBoardController", ['$scope', '$routeParams', '$http', function ($scope, $routeParams, $http) {

    var link = "../AI/data/UserControl.aspx?mode=list";
    $http.get(link).then(function (response) {
        var data = response.data.records;
        userid.setData(data);
    })
}]);

NGAApp.controller("ListController", ['$scope', '$routeParams', '$http', 'NgTableParams', 'NGAToolsData', 'listID', function ($scope, $routeParams, $http, NgTableParams, NGAToolsData, listID) {
    listID.setData($routeParams.teamID);
    var link = "../AI/data/SqlQuery.aspx?mode=" + $routeParams.teamID;
    $http.get(link)
.then(function (response) {
    var data = response.data.records;
    NGAToolsData.setData(data);
    $scope.tableParams = new NgTableParams({}, { dataset: data });
});

}]);

NGAApp.controller('DetailsController', ['$scope', '$routeParams', '$http', 'NGAToolsData', 'listID', function ($scope, $routeParams, $http, NGAToolsData, listID) {

    $scope.pageId = listID.getData();
    $scope.tools = NGAToolsData.getData();
    $scope.whichItem = $routeParams.appIndex;

    if ($scope.pageId == "ALL") {
        $http.get("../AI/data/SqlQuery.aspx?mode=" + $scope.tools[$scope.whichItem].ID).then(function (response) {
            var data = response.data.records;
            var desr = data[0]["Description"];
            $scope.tools[$scope.whichItem].Description = desr;
        });
    }

    if ($routeParams.appIndex > 0) {
        $scope.prevItem = Number($routeParams.appIndex) - 1;
    } else {
        $scope.prevItem = $scope.tools.length - 1;
    }

    if ($routeParams.appIndex < $scope.tools.length - 1) {
        $scope.nextItem = Number($routeParams.appIndex) + 1;
    } else {
        $scope.nextItem = 0;
    }

}]);

NGAApp.controller('AccessController', ['$scope', '$routeParams', '$http', function ($scope, $routeParams, $http) {
    $http.get("../AI/data/accessRequest.aspx").then(function (response) {
        var data = response.data.records;
        //var desr = data[0]["Description"];
        $scope.GSCList = data;
    });
    $scope.roles = [
        { name: "roleradio", id: 1, value: "Admin" },
        { name: "roleradio", id: 2, value: "SuperUser" },
        { name: "roleradio", id: 3, value: "User" },
        { name: "roleradio", id: 4, value: "Export" },
    ];

    // create a blank object to hold our form information
    // $scope will allow this to pass between controller and view
    $scope.formData = { _appid: "" };
    // process the form
    $scope.processForm = function (appid) {
        $scope.formData._appid = appid;
        $http({
            method: 'POST',
            url: '../AI/data/accessRequest.aspx',
            data: $.param($scope.formData),  // pass in data as strings
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  // set the headers so angular passing info as form data (not request payload)
        })
        .success(function (data) {
            console.log(data);
            $scope.message = data;
            //if (!data.success) {
            //    // if not successful, bind errors to error variables
            //    $scope.errorName = data.errors[0];
            //    $scope.errorSuperhero = data.errors[1];
            //} else {
            //    // if successful, bind success message to message
            //    $scope.message = data.message;
            //}
        });
    };

}]);

NGAApp.controller('FormController', ['$scope', '$routeParams', '$http', function ($scope, $routeParams, $http) {
    // create a blank object to hold our form information
    // $scope will allow this to pass between controller and view
    $scope.formData = {};
    // process the form
    $scope.processForm = function (appid) {
        $scope.formData._appid = appid;
        $http({
            method: 'POST',
            url: '../AI/data/accessRequest.aspx',
            data: $.param($scope.formData),  // pass in data as strings
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  // set the headers so angular passing info as form data (not request payload)
        })
        .success(function (data) {
            console.log(data);

            if (!data.success) {
                // if not successful, bind errors to error variables
                $scope.errorName = data.errors.name;
                $scope.errorSuperhero = data.errors.superheroAlias;
            } else {
                // if successful, bind success message to message
                $scope.message = data.message;
            }
        });
    };
}

]);

NGAApp.controller('wikiController', ['$scope', '$routeParams', '$http', function ($scope, $routeParams, $http) {

}
]);

//NGAController.filter("checkedItems", function () {
//    return function (items, showComplete) {
//        var resultArr = [];
//        angular.forEach(items, function (item) {
//            if (item.done == false || showComplete == true) {
//                resultArr.push(item);
//            }
//        });
//        return resultArr;
//    }
//});


//NGAController.controller("ToDoCtrl", ['$scope', '$http', '$filter', function ($scope, $http, $filter) {
//    $scope.actionText="";
//    $scope.todo = { user: "Ozzie",items:[]};
//     $http.get("./data/GetJSON.php").then(function(response){

//         $scope.todo.items=response.data.records;

//        $scope.incompleteCount = function () {
//            var count = 0;
//            angular.forEach($scope.todo.items, function (item) {
//                if (item.done!=true) { count++ }
//            });
//            return count;
//        }

//        $scope.warningLevel = function () {
//            return $scope.incompleteCount() < 3 ? "label label-success" : "label label-warning";
//        }

//        $scope.addNewItem = function () {
//            if ($scope.actionText == "") {return;}
//            var now = new Date();

//            var duedate = $filter('date')(now, 'yyyy-MM-dd HH:mm:ss')  ;
//            $scope.todo.items.push({ action: $scope.actionText, done: false,dueDate: duedate});
//            $scope.actionText="";
//        }

//     });

//}]);

// todoApp.controller("ToDoCtrl", function ($scope) {
//     $scope.todo = {
//         user: "Adam",
//         items:[]
//         //items: [{ action: "Buy Flowers", done: false },
//         //{ action: "Get Shoes", done: false },
//         //{ action: "Collect Tickets", done: true },
//         //{ action: "Call Joe", done: false }]
//     };

//     $scope.incompleteCount = function () {
//         var count = 0;
//         angular.forEach($scope.todo.items, function (item) {
//             if (!item.done) { count++ }
//         });
//         return count;
//     }

//     $scope.warningLevel = function () {
//         return $scope.incompleteCount() < 3 ? "label label-success" : "label label-warning";
//     }

//     $scope.addNewItem = function (actionText) {
//         $scope.todo.items.push({ action: actionText, done: false });
//     }
// });

// Speed up calls to hasOwnProperty
var hasOwnProperty = Object.prototype.hasOwnProperty;

function isEmpty(obj) {

    // null and undefined are "empty"
    if (obj == null) return true;

    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;

    // If it isn't an object at this point
    // it is empty, but it can't be anything *but* empty
    // Is it empty?  Depends on your application.
    if (typeof obj !== "object") return true;

    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and valueOf enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }

    return true;
}

