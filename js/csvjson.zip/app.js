﻿var NGAApp = angular.module('NGAApp', ['ngRoute', 'ngTable']);

NGAApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/list', {
		templateUrl: 'particals/list.html',
		controller: 'ListController'
    }).when('/list/:teamID', {
        templateUrl: 'particals/list.html',
        controller: 'ListController'
    }).when('/details/:appIndex',{
		templateUrl: 'particals/details.html',
		controller: 'DetailsController'
	}).when('/why',{
	    templateUrl: 'particals/qna.html'
	}).when('/Access/:appID',{
	    templateUrl: 'particals/access.html',
	}).when('/Access', {
	    templateUrl: 'particals/access.html',
	    controller: 'AccessController'
	}).when('/dashBoard', {
	    templateUrl: 'particals/toolStatus.html',
	    controller: 'dashBoardController'
	}).when('/wiki', {
	    templateUrl: 'particals/wiki.html',
	    controller: 'wikiController'
	}).otherwise({
	    redirectTo: '/why'
	});

    // use the HTML5 History API
    //$locationProvider.html5Mode({
    //    enabled: true
    //});
}]);
